package ui;

import java.io.File;
import java.io.IOException;
import app.PorkingLotSystem;
import exception.DataLoadException;
import exception.ValidationException;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.image.Image;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import objects.Beef;
import objects.Chicken;
import objects.Egg;
import objects.Pork;
import objects.Product;

// Products page: a grid of product cards with Category filter, Add, Edit and Delete
// INHERITANCE: this page extends VBox, so it IS a VBox (a vertical box) and can hold other nodes.
// It also implements Searchable, so it must provide the search() method.
public class ProductsView extends VBox implements Searchable {
    private PorkingLotSystem system;
    private FlowPane grid = new FlowPane(26, 26);
    private String searchText = "";
    private String category = "All";

    private Product selected;
    private VBox selectedCard;
    private File pickedPicture;

    // Builds the toolbar and the scrolling grid of product cards
    public ProductsView(PorkingLotSystem system) {
        this.system = system;
        setSpacing(14);

        MenuButton categoryButton = new MenuButton("Category", Icons.outline(Icons.FILTER, 18));
        categoryButton.getStyleClass().add("tool-button");
        categoryButton.getItems().addAll(Dialogs.radioItems(
                new String[] { "All", "Pork", "Beef", "Chicken", "Egg" },
                choice -> {
                    category = choice;
                    refresh();
                }));

        Region spacer = Dialogs.spacer();
        HBox toolbar = new HBox(10, categoryButton, spacer);
        toolbar.setAlignment(Pos.CENTER_LEFT);

        if (system.getCurrentUser().canEditProducts()) {
            Button add = Dialogs.toolButton("Add Product", Icons.ADD);
            add.setOnAction(e -> showProductDialog(null));
            Button delete = Dialogs.toolButton("Delete Product", Icons.DELETE);
            delete.setOnAction(e -> deleteSelected());
            toolbar.getChildren().addAll(add, delete);
        }

        grid.setPadding(new Insets(4));
        ScrollPane scroll = new ScrollPane(grid);
        scroll.setFitToWidth(true);
        scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        VBox.setVgrow(scroll, Priority.ALWAYS);

        getChildren().addAll(toolbar, scroll);
        refresh();
    }

    // Called by the header search box: keeps the text and reloads the cards
    // @Override: this is the method promised by the Searchable interface (POLYMORPHISM).
    @Override
    public void search(String text) {
        searchText = text.trim().toLowerCase();
        refresh();
    }

    // Reloads the product cards (using the category filter and the search text)
    public void refresh() {
        selected = null;
        selectedCard = null;
        grid.getChildren().clear();
        boolean canEdit = system.getCurrentUser().canEditProducts();
        for (Product p : system.getAllProducts()) {
            boolean categoryOk = category.equals("All") || p.getCategory().equalsIgnoreCase(category);
            boolean searchOk = p.getName().toLowerCase().contains(searchText);
            if (categoryOk && searchOk) {
                grid.getChildren().add(makeCard(p, canEdit));
            }
        }
        if (grid.getChildren().isEmpty()) {
            Label none = new Label("No products found.");
            none.getStyleClass().add("empty-text");
            grid.getChildren().add(none);
        }
    }

    // Builds one product card: picture, name, category, price, description and Edit button
    private VBox makeCard(Product p, boolean canEdit) {
        Label name = new Label(p.getName());
        name.getStyleClass().add("product-name");
        Label cat = new Label(p.getCategory());
        cat.getStyleClass().add("product-category");
        VBox titles = new VBox(name, cat);

        Region spacer = Dialogs.spacer();
        HBox titleRow = new HBox(titles, spacer);
        titleRow.setAlignment(Pos.CENTER_LEFT);
        if (canEdit) {
            Button edit = Dialogs.pillButton("Edit");
            edit.setOnAction(e -> showProductDialog(p));
            titleRow.getChildren().add(edit);
        }

        Label price = new Label(Format.PESO + Format.price(p.getPricePerUnit()) + " / " + p.getUnit());
        price.getStyleClass().add("product-price");

        Label desc = new Label(p.getDescription());
        desc.setWrapText(true);
        VBox descBox = new VBox(desc);
        descBox.getStyleClass().add("description-box");
        descBox.setMinHeight(70);
        descBox.setPrefHeight(70);

        VBox card = new VBox(4, ProductImages.box(ProductImages.load(p.getId()), 230, 160), titleRow, price, descBox);
        card.getStyleClass().add("product-card");
        card.setPrefWidth(250);
        card.setMinWidth(250);
        card.setOnMouseClicked(e -> {
            if (selectedCard != null) {
                selectedCard.getStyleClass().remove("card-selected");
            }
            selected = p;
            selectedCard = card;
            card.getStyleClass().add("card-selected");
        });
        return card;
    }

    // Deletes the clicked product card after asking for confirmation
    private void deleteSelected() {
        if (selected == null) {
            Dialogs.error("Click a product card first before deleting.");
            return;
        }
        if (Dialogs.confirm("Delete " + selected.getName() + "? This also removes its stock.")) {
            try {
                system.deleteProduct(selected.getId());
                ProductImages.delete(selected.getId());
                refresh();
            } catch (ValidationException e) {
                Dialogs.error(e.getMessage());
            } catch (DataLoadException e) {
                Dialogs.error(e.getMessage());
            }
        }
    }

    // Opens the Add / Edit pop-up (existing == null means Add)
    private void showProductDialog(Product existing) {
        boolean adding = (existing == null);

        TextField id = new TextField();
        TextField name = new TextField();
        TextField price = new TextField();
        TextArea description = new TextArea();
        description.setPrefRowCount(4);
        description.setWrapText(true);

        ComboBox<String> categoryBox = new ComboBox<String>();
        categoryBox.getItems().addAll(Product.CATEGORIES);
        categoryBox.setMaxWidth(Double.MAX_VALUE);

        ComboBox<String> unit = new ComboBox<String>();
        unit.getItems().addAll(Product.UNITS);
        unit.setValue("kg");
        unit.setMaxWidth(Double.MAX_VALUE);
        TextField shelfLife = new TextField();
        TextField stock = new TextField("0");
        TextField reorder = new TextField("10");
        ComboBox<String> eggSize = new ComboBox<String>();
        eggSize.getItems().addAll("Small", "Medium", "Large", "Jumbo");
        eggSize.setValue("Medium");
        eggSize.setMaxWidth(Double.MAX_VALUE);
        TextField perTray = new TextField("30");
        VBox eggBox = new VBox(8, Dialogs.row("Egg size:", eggSize), Dialogs.row("Pieces per tray:", perTray));
        eggBox.setVisible(false);
        eggBox.setManaged(false);
        categoryBox.setOnAction(e -> {
            boolean isEgg = "Egg".equals(categoryBox.getValue());
            eggBox.setVisible(isEgg);
            eggBox.setManaged(isEgg);
        });

        Label title = new Label(adding ? "ADD PRODUCT" : "EDIT PRODUCT");
        title.getStyleClass().add("dialog-title");

        boolean hasPicture = !adding && ProductImages.load(existing.getId()) != null;
        Button changePicture = Dialogs.pillButton(hasPicture ? "Change Picture" : "Add Picture");

        pickedPicture = null;
        StackPane picture = ProductImages.box(adding ? null : ProductImages.load(existing.getId()), 456, 130);
        changePicture.setOnAction(e -> {
            FileChooser chooser = new FileChooser();
            chooser.setTitle("Choose a picture");
            chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Pictures", "*.png", "*.jpg", "*.jpeg", "*.gif"));
            File file = chooser.showOpenDialog(grid.getScene().getWindow());
            if (file != null) {
                pickedPicture = file;
                ProductImages.fill(picture, new Image(file.toURI().toString()), 456, 130);
            }
        });

        VBox form = new VBox(8, title, picture);
        Region gap = Dialogs.spacer();
        HBox pictureRow = new HBox(changePicture, gap);
        pictureRow.setAlignment(Pos.CENTER_LEFT);
        form.getChildren().add(pictureRow);

        if (adding) {
            form.getChildren().addAll(Dialogs.row("Product ID:", id),
                    Dialogs.row("Name:", name), Dialogs.row("Category:", categoryBox),
                    Dialogs.row("Price per unit:", price), Dialogs.row("Unit:", unit),
                    Dialogs.row("Shelf life (days):", shelfLife), eggBox,
                    Dialogs.row("Initial stock:", stock), Dialogs.row("Reorder level:", reorder),
                    Dialogs.row("Description:", description));
        } else {
            pictureRow.getChildren().add(new Label("ID: " + existing.getId()));
            name.setText(existing.getName());
            categoryBox.setValue(existing.getCategory());
            categoryBox.setDisable(true);
            price.setText(Format.price(existing.getPricePerUnit()));
            description.setText(existing.getDescription());
            form.getChildren().addAll(Dialogs.row("Name:", name), Dialogs.row("Category:", categoryBox),
                    Dialogs.row("Price per " + existing.getUnit() + ":", price),
                    Dialogs.row("Description:", description));
        }

        Button save = Dialogs.pillButton("Save");
        Button cancel = Dialogs.pillButton("Cancel");
        Region fill = Dialogs.spacer();
        HBox buttons = new HBox(10, fill, save, cancel);
        form.getChildren().add(buttons);
        form.setPrefWidth(480);

        Stage stage = Dialogs.popup(grid, form);
        cancel.setOnAction(e -> stage.close());
        save.setOnAction(e -> {
            try {
                double priceValue = Double.parseDouble(price.getText().trim());
                if (adding) {
                    addNewProduct(id.getText(), name.getText(), categoryBox.getValue(), description.getText(),
                            priceValue, unit.getValue(), Integer.parseInt(shelfLife.getText().trim()),
                            eggSize.getValue(), perTray.getText(),
                            Double.parseDouble(stock.getText().trim()), Double.parseDouble(reorder.getText().trim()));
                } else {
                    system.editProduct(existing.getId(), name.getText(), description.getText(),
                            priceValue, existing.getUnit(), existing.getShelfLifeDays());
                }
                String savedId = adding ? id.getText().trim() : existing.getId();
                if (pickedPicture != null) {
                    ProductImages.save(savedId, pickedPicture);
                }
                stage.close();
                refresh();
            } catch (IOException ex) {
                Dialogs.error("The product was saved, but the picture could not be copied.");
            } catch (NumberFormatException ex) {
                Dialogs.error("Please enter valid numbers for the number fields.");
            } catch (ValidationException ex) {
                Dialogs.error(ex.getMessage());
            } catch (DataLoadException ex) {
                Dialogs.error(ex.getMessage());
            }
        });
        stage.showAndWait();
    }

    // Builds the right kind of Product object and adds it to the system
    private void addNewProduct(String id, String name, String category, String description, double price,
                               String unit, int shelfLife, String eggSize, String perTray,
                               double stock, double reorder)
            throws ValidationException, DataLoadException {
        if (category == null) {
            throw new ValidationException("Please choose a category.");
        }
        Product p;
        if (category.equals("Egg")) {
            p = new Egg(id, name, description, price, unit, shelfLife, eggSize, Integer.parseInt(perTray.trim()));
        } else if (category.equals("Pork")) {
            p = new Pork(id, name, description, price, unit, shelfLife);
        } else if (category.equals("Beef")) {
            p = new Beef(id, name, description, price, unit, shelfLife);
        } else {
            p = new Chicken(id, name, description, price, unit, shelfLife);
        }
        system.addProduct(p, stock, reorder);
    }
}
