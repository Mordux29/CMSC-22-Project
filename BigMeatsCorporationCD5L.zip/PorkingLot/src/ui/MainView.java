package ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import app.PorkingLotSystem;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import objects.User;

// The frame around every page: sidebar on the left, header on top, the current page below
// INHERITANCE: extends BorderPane, a layout with a left side (sidebar) and a center (header and page).
public class MainView extends BorderPane {
    private PorkingLotSystem system;
    private Runnable onLogout;

    private VBox nav = new VBox(27);
    private Label titleLabel = new Label();
    private Label subtitleLabel = new Label();
    private StackPane pageArea = new StackPane();

    private OverviewView overview;
    private ProductsView products;
    private InventoryView inventory;
    private TransactionsView transactions;
    private AccountsView accounts;

    private HBox tools = new HBox(12);
    private TextField searchField = new TextField();
    private Searchable searchable;
    private Button rangeButton = new Button("This month");
    private boolean showingDay = false;
    private Node searchBoxNode;

    // Creates the pages, builds the sidebar and header, and shows the first page (Overview, or Add Sale for a clerk)
    public MainView(PorkingLotSystem system, Runnable onLogout) {
        this.system = system;
        this.onLogout = onLogout;
        this.overview = new OverviewView(system);
        this.products = new ProductsView(system);
        this.inventory = new InventoryView(system);

        this.transactions = new TransactionsView(system, isManager() ? null : system.getCurrentUser().getUsername(),
                () -> showAddSale(), null);
        if (system.getCurrentUser().canManageAccounts()) {
            this.accounts = new AccountsView(system, name -> showClerkHistory(name));
        }

        setLeft(buildSidebar());

        VBox right = new VBox(23, buildHeader(), pageArea);
        right.setPadding(new Insets(15, 24, 15, 20));
        VBox.setVgrow(pageArea, Priority.ALWAYS);
        setCenter(right);

        showPage(isManager() ? "Overview" : "Add Sale");
    }

    // Builds the pink sidebar: logo, navigation buttons, Logout and the credit line
    private VBox buildSidebar() {
        VBox sidebar = new VBox();
        sidebar.getStyleClass().add("sidebar");
        sidebar.setPrefWidth(300);
        sidebar.setMinWidth(300);
        sidebar.setMaxWidth(300);

        VBox top = new VBox();
        top.setPadding(new Insets(26, 20, 0, 22));
        if (MainView.class.getResource("/ui/images/logo.png") != null) {
            ImageView logo = new ImageView(new Image(MainView.class.getResource("/ui/images/logo.png").toExternalForm()));
            logo.setFitWidth(260);
            logo.setPreserveRatio(true);
            top.getChildren().add(logo);
        }

        nav.setPadding(new Insets(34, 0, 0, 10));
        if (isManager()) {
            addNavButton("Overview");
            addNavButton("Products");
            addNavButton("Inventory");
            addNavButton("Transactions");
            addNavButton("Accounts");
        } else {
            addNavButton("Add Sale");
            addNavButton("My Sales");
            addNavButton("Inventory");
        }

        Region spacer = new Region();
        VBox.setVgrow(spacer, Priority.ALWAYS);

        Region divider = new Region();
        divider.getStyleClass().add("sidebar-divider");
        divider.setMinHeight(2);
        divider.setPrefHeight(2);
        divider.setMaxHeight(2);
        VBox.setMargin(divider, new Insets(0, 10, 0, 10));

        Button logout = new Button("Logout", Icons.outline(Icons.LOGOUT, 30));
        logout.getStyleClass().add("logout-button");
        logout.setContentDisplay(ContentDisplay.LEFT);
        logout.setGraphicTextGap(14);
        logout.setAlignment(Pos.CENTER);
        logout.setMaxWidth(Double.MAX_VALUE);
        logout.setPrefHeight(70);
        logout.setOnAction(e -> {
            system.logout();
            onLogout.run();
        });

        Label credit = new Label("Made by Big Meats Corporation");
        credit.getStyleClass().add("credit-label");
        credit.setMaxWidth(Double.MAX_VALUE);
        credit.setAlignment(Pos.CENTER);
        credit.setPadding(new Insets(0, 0, 22, 0));

        sidebar.getChildren().addAll(top, nav, spacer, divider, logout, credit);
        return sidebar;
    }

    // Adds one navigation button to the sidebar
    private void addNavButton(String name) {
        Button button = new Button(name);
        button.getStyleClass().add("nav-button");
        button.setMaxWidth(Double.MAX_VALUE);
        button.setPrefHeight(62);
        button.setMinHeight(62);
        button.setOnAction(e -> showPage(name));
        nav.getChildren().add(button);
    }

    // Builds the header card: page title, the page tools, and the user name and role
    private HBox buildHeader() {
        titleLabel.getStyleClass().add("page-title");
        subtitleLabel.getStyleClass().add("page-subtitle");
        VBox titles = new VBox(titleLabel, subtitleLabel);
        titles.setAlignment(Pos.CENTER_LEFT);

        Region spacer = Dialogs.spacer();

        rangeButton.getStyleClass().add("range-button");
        rangeButton.setPrefSize(126, 50);
        rangeButton.setOnAction(e -> {
            showingDay = !showingDay;
            rangeButton.setText(showingDay ? "This day" : "This month");
            overview.setDay(showingDay);
        });

        searchField.setPromptText("Search");
        searchField.textProperty().addListener((obs, oldText, newText) -> {
            if (searchable != null) {
                searchable.search(newText);
            }
        });
        HBox searchBox = new HBox(8, Icons.outline(Icons.SEARCH, 18), searchField);
        searchBox.getStyleClass().add("search-box");
        searchBox.setAlignment(Pos.CENTER_LEFT);
        searchBox.setPrefSize(310, 40);
        searchBox.setMaxHeight(40);
        searchBoxNode = searchBox;

        User user = system.getCurrentUser();
        StackPane avatar = new StackPane(new Circle(21, Color.web("#F6C2C3")),
                Icons.filled(Icons.PERSON, 26, Color.WHITE));
        Label name = new Label(user.getUsername());
        name.getStyleClass().add("user-name");
        Label role = new Label(user.getRole());
        role.getStyleClass().add("user-role");
        VBox userText = new VBox(name, role);
        userText.setAlignment(Pos.CENTER_LEFT);

        HBox header = new HBox(14, titles, spacer, tools, avatar, userText);
        header.getStyleClass().add("card");
        header.setAlignment(Pos.CENTER_LEFT);
        header.setPadding(new Insets(0, 22, 0, 30));
        header.setPrefHeight(73);
        header.setMinHeight(73);
        header.setMaxHeight(73);
        tools.setAlignment(Pos.CENTER_RIGHT);
        return header;
    }

    // Returns true if the logged-in user is the Manager
    private boolean isManager() {
        return system.getCurrentUser().canViewAllTransactions();
    }

    // Marks the given sidebar button as the active one
    private void highlight(String navName) {
        for (int i = 0; i < nav.getChildren().size(); i++) {
            Button b = (Button) nav.getChildren().get(i);
            b.getStyleClass().remove("nav-button-active");
            if (b.getText().equals(navName)) {
                b.getStyleClass().add("nav-button-active");
            }
        }
    }

    // Shows a page: sets the header text and tool, connects the search box, and swaps the page
    private void show(String navName, String title, String subtitle, Node tool, Searchable searchTarget, Node page) {
        highlight(navName);
        titleLabel.setText(title);
        subtitleLabel.setText(subtitle);
        tools.getChildren().clear();
        if (tool != null) {
            tools.getChildren().add(tool);
        }
        searchable = null;
        searchField.clear();
        if (searchTarget != null) {
            searchTarget.search("");
            searchable = searchTarget;
        }
        pageArea.getChildren().setAll(page);
    }

    // Shows the page of the clicked sidebar button
    private void showPage(String name) {
        if (name.equals("Overview")) {
            overview.refresh();
            show(name, "Overview", "Sales, stock alerts, and wallet", rangeButton, null, overview);
        } else if (name.equals("Products")) {
            show(name, "Products", "Manage your items, prices, and descriptions", searchBoxNode, products, products);
        } else if (name.equals("Inventory")) {
            show(name, "Inventory", "Track stock levels, restocks, and expiry dates", searchBoxNode, inventory, inventory);
        } else if (name.equals("Add Sale")) {
            showAddSale();
        } else if (name.equals("My Sales")) {
            show(name, "My Sales", "Review and void your recorded sales", searchBoxNode, transactions, transactions);
        } else if (name.equals("Transactions")) {
            show(name, "Transactions", "Review every sale and its status", searchBoxNode, transactions, transactions);
        } else if (name.equals("Accounts")) {
            show(name, "Account", "Manage Clerk Accounts", searchBoxNode, accounts, accounts);
        }
    }

    // Shows the Add Sale screen with today's date in the header
    private void showAddSale() {
        Label date = new Label(LocalDate.now().format(DateTimeFormatter.ofPattern("MMMM d, yyyy")));
        date.getStyleClass().add("date-label");
        if (isManager()) {
            show("Transactions", "Transactions", "Record customer purchases and update stock", date, null,
                    new AddSaleView(system, () -> showPage("Transactions")));
        } else {
            show("Add Sale", "Add Sale", "Record customer purchases and update stock", date, null,
                    new AddSaleView(system, () -> showPage("My Sales"), () -> showAddSale()));
        }
    }

    // Shows the sale history of one clerk (opened from the Accounts page)
    private void showClerkHistory(String clerkUsername) {
        TransactionsView history = new TransactionsView(system, clerkUsername, null, () -> showPage("Accounts"));
        show("Accounts", "Account", "Manage Clerk Accounts", searchBoxNode, history, history);
    }
}
