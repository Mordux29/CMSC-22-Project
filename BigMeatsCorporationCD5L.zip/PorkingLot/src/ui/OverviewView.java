package ui;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import dashboard.Dashboard;
import exception.ValidationException;
import app.PorkingLotSystem;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.util.StringConverter;
import objects.InventoryItem;
import objects.Sale;
import objects.SaleItem;
import objects.Transaction;

// Overview page: revenue cards, revenue chart, Needs Attention list and Top Selling list
// INHERITANCE: extends VBox, so this page IS a VBox and its parts are added with getChildren().add(...).
public class OverviewView extends VBox {
    private PorkingLotSystem system;

    private Label revenueLabel = new Label();
    private Label salesCountLabel = new Label();
    private Label walletLabel = new Label();

    private BarChart<String, Number> chart;
    private CategoryAxis xAxis;
    private boolean day = false;

    private HBox attentionHeader;
    private VBox attentionRows = new VBox();
    private VBox topRows = new VBox();

    // Builds the three parts of the page and fills them with data
    public OverviewView(PorkingLotSystem system) {
        this.system = system;
        setSpacing(29);

        getChildren().add(buildStatRow());
        getChildren().add(buildChartCard());
        getChildren().add(buildBottomRow());

        refresh();
    }

    // Builds the row with the Revenue, Sales Count and Wallet Balance cards
    private HBox buildStatRow() {
        VBox revenueCard = buildStatCard("Revenue", Icons.REVENUE, revenueLabel);
        VBox salesCard = buildStatCard("Sales Count", Icons.SALES, salesCountLabel);
        VBox walletCard = buildStatCard("Wallet Balance", Icons.WALLET, walletLabel);

        HBox row = new HBox(38, revenueCard, salesCard, walletCard);
        row.setPrefHeight(136);
        row.setMinHeight(120);
        return row;
    }

    // Builds one stat card (pink title bar with an icon and a big value)
    private VBox buildStatCard(String title, String iconPath, Label valueLabel) {
        valueLabel.getStyleClass().add("stat-value");
        HBox body = new HBox(valueLabel);
        body.setAlignment(Pos.CENTER_LEFT);
        body.setPadding(new Insets(0, 20, 0, 20));
        VBox.setVgrow(body, Priority.ALWAYS);

        VBox card = new VBox(makeHeader(title, iconPath), body);
        card.getStyleClass().add("card");
        HBox.setHgrow(card, Priority.ALWAYS);
        card.setPrefWidth(100);
        card.setMaxWidth(Double.MAX_VALUE);
        return card;
    }

    // Builds the card that holds the revenue bar chart
    private VBox buildChartCard() {
        xAxis = new CategoryAxis();
        xAxis.setLabel("Day of Month");
        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Sales (Revenue)");
        yAxis.setTickLabelFormatter(new PesoConverter());

        chart = new BarChart<String, Number>(xAxis, yAxis);
        chart.getStyleClass().add("revenue-chart");
        chart.setLegendVisible(false);
        chart.setAnimated(false);
        chart.setCategoryGap(6);
        chart.setBarGap(0);
        chart.setVerticalGridLinesVisible(false);
        chart.setHorizontalGridLinesVisible(true);
        chart.setAlternativeRowFillVisible(false);
        chart.setHorizontalZeroLineVisible(false);
        VBox.setVgrow(chart, Priority.ALWAYS);

        VBox card = new VBox(makeHeader("Revenue Chart", Icons.CHART), chart);
        card.getStyleClass().add("card");
        card.setPrefHeight(345);
        card.setMinHeight(220);
        VBox.setVgrow(card, Priority.ALWAYS);
        return card;
    }

    // Builds the Needs Attention and Top Selling cards
    private HBox buildBottomRow() {
        attentionHeader = makeHeader("Needs Attention", Icons.ALERT);
        ScrollPane attentionScroll = makeScroll(attentionRows);
        VBox attentionCard = new VBox(attentionHeader, attentionScroll);
        attentionCard.getStyleClass().add("card");
        HBox.setHgrow(attentionCard, Priority.ALWAYS);
        attentionCard.setPrefWidth(751);

        ScrollPane topScroll = makeScroll(topRows);
        VBox topCard = new VBox(makeHeader("Top Selling", Icons.TOP), topScroll);
        topCard.getStyleClass().add("card");
        topCard.setPrefWidth(311);
        topCard.setMinWidth(260);

        HBox row = new HBox(34, attentionCard, topCard);
        row.setPrefHeight(345);
        row.setMinHeight(220);
        VBox.setVgrow(row, Priority.ALWAYS);
        return row;
    }

    // Builds the pink bar at the top of a card (an icon and a title)
    private HBox makeHeader(String title, String iconPath) {
        Label titleLabel = new Label(title);
        titleLabel.getStyleClass().add("card-title");
        HBox header = new HBox(12, Icons.outline(iconPath, 24), titleLabel);
        header.getStyleClass().add("card-header");
        header.setAlignment(Pos.CENTER_LEFT);
        header.setPadding(new Insets(0, 20, 0, 20));
        header.setPrefHeight(55);
        header.setMinHeight(55);
        header.setMaxHeight(55);
        return header;
    }

    // Puts the rows of a list inside a scroll pane
    private ScrollPane makeScroll(VBox rows) {
        rows.setPadding(new Insets(10));
        ScrollPane scroll = new ScrollPane(rows);
        scroll.setFitToWidth(true);
        scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scroll.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
        VBox.setVgrow(scroll, Priority.ALWAYS);
        return scroll;
    }

    // Loads all the numbers again (call this whenever the data may have changed)
    public void refresh() {
        Dashboard dashboard;
        try {
            dashboard = system.getDashboard();
        } catch (ValidationException e) {
            return;
        }

        LocalDate today = LocalDate.now();
        fillRevenue(dashboard, today);
        walletLabel.setText(Format.money(dashboard.getWalletBalance()));
        fillNeedsAttention(today);
        fillTopSelling(dashboard, today);
    }

    // Switches between "this month" (false) and "today" (true) and reloads the data
    public void setDay(boolean day) {
        this.day = day;
        refresh();
    }

    // Checks if a date belongs to the chosen period (today, or this month)
    private boolean inPeriod(LocalDate date, LocalDate today) {
        if (day) {
            return date.equals(today);
        }
        return date.getYear() == today.getYear() && date.getMonth() == today.getMonth();
    }

    // Fills Revenue, Sales Count and the chart (a bar per day of the month, or per hour of today)
    private void fillRevenue(Dashboard dashboard, LocalDate today) {
        XYChart.Series<String, Number> series = new XYChart.Series<String, Number>();
        double revenue = 0;
        int salesCount = 0;
        if (day) {
            double[] perHour = new double[24];
            for (Transaction t : dashboard.getRecentTransactions(Integer.MAX_VALUE)) {
                if (t instanceof Sale && !t.isVoided() && t.getDateTime().toLocalDate().equals(today)) {
                    perHour[t.getDateTime().getHour()] += t.getAmount();
                }
            }
            for (int h = 0; h < 24; h++) {
                series.getData().add(new XYChart.Data<String, Number>(String.valueOf(h), perHour[h]));
            }
            revenue = dashboard.getTodaySalesTotal();
            salesCount = dashboard.getTodaySalesCount();
            xAxis.setLabel("Hour of Day");
        } else {
            for (int d = 1; d <= today.lengthOfMonth(); d++) {
                LocalDate date = today.withDayOfMonth(d);
                double total = dashboard.getSalesTotalOn(date);
                revenue = revenue + total;
                salesCount = salesCount + dashboard.getSalesCountOn(date);
                series.getData().add(new XYChart.Data<String, Number>(String.valueOf(d), total));
            }
            xAxis.setLabel("Day of Month");
        }
        chart.getData().clear();
        chart.getData().add(series);

        revenueLabel.setText(Format.money(revenue));
        salesCountLabel.setText(salesCount + " Sales");
    }

    // Fills the expired, expiring, out-of-stock and low-stock rows and the four counters
    private void fillNeedsAttention(LocalDate today) {
        ArrayList<String[]> expiredRows = new ArrayList<String[]>();
        ArrayList<String[]> expiringRows = new ArrayList<String[]>();
        ArrayList<String[]> outRows = new ArrayList<String[]>();
        ArrayList<String[]> lowRows = new ArrayList<String[]>();

        for (InventoryItem item : system.getInventoryItems()) {
            String name = item.getProduct().getName();
            if (StockRules.isExpired(item) || StockRules.isExpiring(item)) {
                long days = ChronoUnit.DAYS.between(today, item.getExpiryDate());
                if (StockRules.isExpired(item)) {
                    long ago = -days;
                    expiredRows.add(new String[] { name, "Expired " + ago + (ago == 1 ? " day ago" : " days ago") });
                } else if (days == 0) {
                    expiringRows.add(new String[] { name, "Expires today" });
                } else {
                    expiringRows.add(new String[] { name, "Expires in " + days + (days == 1 ? " day" : " days") });
                }
            }
            if (StockRules.isOut(item)) {
                outRows.add(new String[] { name, "Out of Stock" });
            } else if (StockRules.isLow(item)) {
                lowRows.add(new String[] { name,
                        "Low Stock: " + Format.stock(item.getStock()) + " " + item.getProduct().getUnit() + " left" });
            }
        }

        while (attentionHeader.getChildren().size() > 2) {
            attentionHeader.getChildren().remove(2);
        }
        Region gap = Dialogs.spacer();
        attentionHeader.getChildren().addAll(gap,
                makeCounter("Low Stock: ", lowRows.size()),
                makeCounter("Out of Stock: ", outRows.size()),
                makeCounter("Expiring: ", expiringRows.size()),
                makeCounter("Expired: ", expiredRows.size()));
        attentionHeader.setSpacing(14);

        ArrayList<String[]> all = new ArrayList<String[]>();
        all.addAll(expiredRows);
        all.addAll(expiringRows);
        all.addAll(outRows);
        all.addAll(lowRows);

        attentionRows.getChildren().clear();
        if (all.isEmpty()) {
            attentionRows.getChildren().add(emptyText("Nothing needs attention."));
        }
        for (int i = 0; i < all.size(); i++) {
            Label name = new Label(all.get(i)[0]);
            Label status = new Label(all.get(i)[1]);
            name.getStyleClass().add("row-text");
            status.getStyleClass().add("row-text");
            Region spacer = Dialogs.spacer();
            HBox row = new HBox(name, spacer, status);
            row.setAlignment(Pos.CENTER_LEFT);
            row.setPadding(new Insets(0, 20, 0, 44));
            row.setMinHeight(50);
            row.setPrefHeight(50);
            row.getStyleClass().add(i % 2 == 0 ? "row-pink" : "row-white");
            attentionRows.getChildren().add(row);
        }
    }

    // Fills the best-selling products of the chosen period (up to 10, by money earned)
    private void fillTopSelling(Dashboard dashboard, LocalDate today) {
        Map<String, Double> totals = new LinkedHashMap<String, Double>();
        for (Transaction t : dashboard.getRecentTransactions(Integer.MAX_VALUE)) {
            if (t instanceof Sale && !t.isVoided() && inPeriod(t.getDateTime().toLocalDate(), today)) {
                for (SaleItem item : ((Sale) t).getItems()) {
                    String productName = item.getProductName();
                    double soFar = 0;
                    if (totals.containsKey(productName)) {
                        soFar = totals.get(productName);
                    }
                    totals.put(productName, soFar + item.getSubtotal());
                }
            }
        }

        ArrayList<String> names = new ArrayList<String>(totals.keySet());

        topRows.getChildren().clear();
        if (names.isEmpty()) {
            topRows.getChildren().add(emptyText(day ? "No sales yet today." : "No sales yet this month."));
        }

        int rankNumber = 1;
        while (!names.isEmpty() && rankNumber <= 10) {
            String best = names.get(0);
            for (String productName : names) {
                if (totals.get(productName) > totals.get(best)) {
                    best = productName;
                }
            }
            names.remove(best);

            Label rank = new Label(rankNumber + ".");
            rank.setMinWidth(40);
            Label name = new Label(best);
            Label amount = new Label(Format.PESO + String.format("%,.0f", totals.get(best)));
            rank.getStyleClass().add("top-row-text");
            name.getStyleClass().add("top-row-text");
            amount.getStyleClass().add("top-row-text");
            Region spacer = Dialogs.spacer();
            HBox row = new HBox(rank, name, spacer, amount);
            row.setAlignment(Pos.CENTER_LEFT);
            row.setPadding(new Insets(0, 14, 0, 10));
            row.setMinHeight(32);
            row.setPrefHeight(32);
            row.getStyleClass().add(rankNumber % 2 == 1 ? "row-pink" : "row-white");
            topRows.getChildren().add(row);
            rankNumber++;
        }
    }

    // Builds a header counter such as "Low Stock: 4" with the number in bold
    private Node makeCounter(String text, int count) {
        Label label = new Label(text);
        Label value = new Label(String.valueOf(count));
        label.getStyleClass().add("attention-summary");
        value.getStyleClass().add("attention-summary");
        value.setStyle("-fx-font-weight: bold;");
        HBox box = new HBox(label, value);
        box.setAlignment(Pos.CENTER_LEFT);
        return box;
    }

    // Creates the grey text shown when a list is empty
    private Label emptyText(String text) {
        Label label = new Label(text);
        label.getStyleClass().add("empty-text");
        label.setPadding(new Insets(14, 10, 0, 34));
        return label;
    }

    // Shows the numbers on the chart's money axis with the peso sign
    // INHERITANCE: extends StringConverter and @Override below fills in the methods it requires.
    private static class PesoConverter extends StringConverter<Number> {
        // Turns an axis number into text such as ₱1,500
        @Override
        public String toString(Number n) {
            return Format.PESO + String.format("%,.0f", n.doubleValue());
        }

        // Required by StringConverter but never used
        @Override
        public Number fromString(String text) {
            return 0;
        }
    }
}
