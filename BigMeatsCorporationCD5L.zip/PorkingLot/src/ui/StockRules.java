package ui;

import dashboard.Dashboard;
import objects.InventoryItem;

// The stock categories used by the Overview and Inventory pages (so both agree)
public class StockRules {
    // True if the item has no stock left
    public static boolean isOut(InventoryItem i)      { return i.getStock() <= 0; }

    // True if the item is low on stock but not completely out
    public static boolean isLow(InventoryItem i)      { return i.isLowStock() && !isOut(i); }

    // True if the item has stock that is already expired
    public static boolean isExpired(InventoryItem i)  { return i.isExpired(); }

    // True if the item expires soon but is not expired yet
    public static boolean isExpiring(InventoryItem i) {
        return i.isExpiringSoon(Dashboard.EXPIRING_DAYS) && !i.isExpired();
    }
}
