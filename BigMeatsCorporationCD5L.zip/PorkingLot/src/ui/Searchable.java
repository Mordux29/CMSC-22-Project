package ui;

// A page that reacts to the search box in the header
// ABSTRACTION: an interface is a promise. A class that "implements" Searchable must write a search() method,
// so the header search box can call search() on any page without knowing which page it is.
public interface Searchable {
    // Called every time the text in the search box changes
    void search(String text);
}
