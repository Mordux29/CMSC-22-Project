package ui;

import java.time.LocalDate;
import java.util.ArrayList;
import app.PorkingLotSystem;
import exception.DataLoadException;
import exception.ValidationException;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import objects.Sale;
import objects.SaleItem;
import objects.Transaction;

// Transactions page (also My Sales for a clerk, and Sale History when opened from Accounts)
// INHERITANCE: this page extends VBox, so it IS a VBox (a vertical box) and can hold other nodes.
// It also implements Searchable, so it must provide the search() method.
public class TransactionsView extends VBox implements Searchable {
    private PorkingLotSystem system;
    private String clerk;

    private TableView<Transaction> table = new TableView<Transaction>();
    private ObservableList<Transaction> rows = FXCollections.observableArrayList();
    private HBox cards = new HBox(24);
    private Button filterButton;

    private String searchText = "";
    private LocalDate dateFilter = null;

    // Builds the toolbar, the cards and the table
    public TransactionsView(PorkingLotSystem system, String clerk, Runnable onAddSale, Runnable onReturn) {
        this.system = system;
        this.clerk = clerk;
        setSpacing(12);

        HBox toolbar = new HBox(10);
        toolbar.setAlignment(Pos.CENTER_LEFT);
        if (clerk != null && onReturn != null) {
            Button back = Dialogs.toolButton("Return", Icons.RETURN);
            back.setOnAction(e -> onReturn.run());
            toolbar.getChildren().add(back);
        }
        filterButton = Dialogs.toolButton("Filter", Icons.FILTER);
        filterButton.setOnAction(e -> showFilterDialog());
        Region spacer = Dialogs.spacer();
        toolbar.getChildren().addAll(filterButton, spacer);
        if (system.getCurrentUser().canProcessTransactions()) {
            if (clerk == null) {
                Button add = Dialogs.toolButton("Add Sale", Icons.ADD);
                add.setOnAction(e -> onAddSale.run());
                toolbar.getChildren().add(add);
            }
            Button voidButton = Dialogs.toolButton("Void Transaction", Icons.DELETE);
            voidButton.setOnAction(e -> voidSelected());
            toolbar.getChildren().add(voidButton);
        }

        buildTable();
        VBox tableCard = new VBox(table);
        tableCard.getStyleClass().add("card");
        tableCard.setPadding(new Insets(10));
        VBox.setVgrow(table, Priority.ALWAYS);
        VBox.setVgrow(tableCard, Priority.ALWAYS);

        getChildren().addAll(toolbar, cards, tableCard);
        refresh();
    }

    // Gives the text a column shows for one transaction
    private interface CellText {
        String get(Transaction t);
    }

    // Builds the transaction table, its Items link column and the grey voided rows
    private void buildTable() {
        addColumn("TRANSACTION ID", t -> t.getId());
        addColumn("DATE AND TIME", t -> t.getDateTimeText());
        addColumn("RECORDED BY", t -> t.getClerkUsername());
        addColumn("CUSTOMER NAME", t -> t.getCustomerName());

        TableColumn<Transaction, String> items = new TableColumn<Transaction, String>("ITEMS");
        items.setCellValueFactory(cell -> new SimpleStringProperty(itemsText(cell.getValue())));
        items.setSortable(false);
        items.setCellFactory(col -> new ItemsLinkCell());
        table.getColumns().add(items);

        addColumn("TOTAL", t -> Format.money(t.getAmount()));

        table.setRowFactory(tv -> new TransactionRow());

        table.setItems(rows);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        table.setPlaceholder(new Label("No transactions found."));
    }

    // Adds one text column to the table
    private void addColumn(String title, CellText text) {
        TableColumn<Transaction, String> column = new TableColumn<Transaction, String>(title);
        column.setCellValueFactory(cell -> new SimpleStringProperty(text.get(cell.getValue())));
        column.setSortable(false);
        table.getColumns().add(column);
    }

    // Writes the number of items of a transaction, for example "3 items"
    private String itemsText(Transaction t) {
        if (t instanceof Sale) {
            int n = ((Sale) t).getItems().size();
            return n + (n == 1 ? " item" : " items");
        }
        return "-";
    }

    // Called by the header search box: keeps the text and reloads the table
    // @Override: this is the method promised by the Searchable interface (POLYMORPHISM).
    @Override
    public void search(String text) {
        searchText = text.trim().toLowerCase();
        refresh();
    }

    // Reloads the transactions (newest first) using the day filter and the search text
    public void refresh() {
        ArrayList<Transaction> all;
        try {
            if (clerk == null || !system.getCurrentUser().canViewAllTransactions()) {
                all = system.getTransactionHistory();
            } else {
                all = system.getClerkHistory(clerk);
            }
        } catch (ValidationException e) {
            return;
        }
        all = new ArrayList<Transaction>(all);
        all.sort((a, b) -> b.getDateTime().compareTo(a.getDateTime()));

        fillCards(all);

        rows.clear();
        for (Transaction t : all) {
            boolean dateOk = dateFilter == null || t.getDateTime().toLocalDate().equals(dateFilter);
            boolean searchOk = t.getId().toLowerCase().contains(searchText)
                    || t.getCustomerName().toLowerCase().contains(searchText)
                    || t.getClerkUsername().toLowerCase().contains(searchText);
            if (dateOk && searchOk) {
                rows.add(t);
            }
        }
    }

    // Fills the three small cards above the table
    private void fillCards(ArrayList<Transaction> all) {
        LocalDate today = LocalDate.now();
        double income = 0, voidedAmount = 0, totalSales = 0;
        int voidedCount = 0, saleCount = 0;
        for (Transaction t : all) {
            boolean isToday = t.getDateTime().toLocalDate().equals(today);
            if (t.isVoided()) {
                if (clerk != null || isToday) {
                    voidedCount++;
                    voidedAmount += t.getAmount();
                }
            } else {
                totalSales += t.getAmount();
                saleCount++;
                if (isToday) {
                    income += t.getAmount();
                }
            }
        }

        Label voidedCountLabel = new Label(voidedCount + (voidedCount == 1 ? " Transaction" : " Transactions"));
        Label voidedAmountLabel = new Label(Format.money(voidedAmount));
        voidedCountLabel.getStyleClass().add("mini-card-value");
        voidedAmountLabel.getStyleClass().add("mini-card-value");
        HBox voidedValue = new HBox(24, voidedCountLabel, voidedAmountLabel);

        cards.getChildren().clear();
        if (clerk == null) {
            cards.getChildren().addAll(
                    statCard("Wallet Balance", Icons.WALLET, valueLabel(Format.money(system.getWalletBalance())), 240),
                    statCard("Income Today", Icons.REVENUE, valueLabel(Format.money(income)), 240),
                    statCard("Voided Today", Icons.ALERT, voidedValue, 300));
        } else {
            cards.getChildren().addAll(
                    statCard("Total Sales", Icons.WALLET, valueLabel(Format.money(totalSales)), 240),
                    statCard("Sale Count", Icons.SALES, valueLabel(saleCount + (saleCount == 1 ? " Sale" : " Sales")), 240),
                    statCard("Voided", Icons.ALERT, voidedValue, 300));
        }
    }

    // Creates the value text of a card
    private Label valueLabel(String text) {
        Label l = new Label(text);
        l.getStyleClass().add("mini-card-value");
        return l;
    }

    // Builds one small card with an icon, a title and a value
    private VBox statCard(String title, String icon, Node value, double width) {
        Label label = new Label(title);
        label.getStyleClass().add("mini-card-label");
        HBox top = new HBox(8, Icons.outline(icon, 18), label);
        top.setAlignment(Pos.CENTER_LEFT);
        VBox card = new VBox(6, top, value);
        card.getStyleClass().add("card");
        card.setPadding(new Insets(12, 16, 12, 16));
        card.setPrefWidth(width);
        card.setMinWidth(width);
        return card;
    }

    // Voids the selected transaction after asking for confirmation
    private void voidSelected() {
        Transaction t = table.getSelectionModel().getSelectedItem();
        if (t == null) {
            Dialogs.error("Click a transaction first before voiding.");
            return;
        }
        if (Dialogs.confirm("Void transaction " + t.getId() + "? Its stock and money will be returned.")) {
            try {
                system.voidTransaction(t.getId());
                refresh();
            } catch (ValidationException e) {
                Dialogs.error(e.getMessage());
            } catch (DataLoadException e) {
                Dialogs.error(e.getMessage());
            }
        }
    }

    // Opens the day filter pop-up (pick a date, or clear it)
    private void showFilterDialog() {
        Label title = new Label("FILTER BY DAY");
        title.getStyleClass().add("dialog-title");
        DatePicker picker = new DatePicker(dateFilter);
        picker.setMaxWidth(Double.MAX_VALUE);

        Button apply = Dialogs.pillButton("Apply");
        Button clear = Dialogs.pillButton("Clear");
        Button cancel = Dialogs.pillButton("Cancel");
        Region fill = Dialogs.spacer();
        HBox buttons = new HBox(10, clear, fill, apply, cancel);

        VBox form = new VBox(10, title, Dialogs.row("Day:", picker), buttons);
        form.setPrefWidth(380);
        Stage stage = Dialogs.popup(table, form);
        apply.setOnAction(e -> setDateFilter(picker.getValue(), stage));
        clear.setOnAction(e -> setDateFilter(null, stage));
        cancel.setOnAction(e -> stage.close());
        stage.showAndWait();
    }

    // Applies the chosen day, updates the Filter button text and reloads the table
    private void setDateFilter(LocalDate date, Stage stage) {
        dateFilter = date;
        filterButton.setText(date == null ? "Filter" : "Filter: " + date);
        stage.close();
        refresh();
    }

    // Opens a pop-up with every item line of a transaction
    private void showItems(Transaction t) {
        Label title = new Label(t.getId() + (t.isVoided() ? "  (VOIDED)" : ""));
        title.getStyleClass().add("dialog-title");
        Label info = new Label("Customer: " + t.getCustomerName() + "   |   Recorded by: " + t.getClerkUsername()
                + "\n" + t.getDateTimeText());
        info.getStyleClass().add("form-label");

        VBox lines = new VBox();
        lines.getChildren().add(itemRow("ITEM", "QTY", "UNIT PRICE", "SUBTOTAL", true));
        if (t instanceof Sale) {
            for (SaleItem item : ((Sale) t).getItems()) {
                lines.getChildren().add(itemRow(item.getProductName(),
                        Format.price(item.getQuantity()) + " " + item.getUnit(),
                        Format.PESO + Format.price(item.getUnitPrice()), Format.money(item.getSubtotal()), false));
            }
        } else {
            lines.getChildren().add(new Label(t.getDetails()));
        }
        ScrollPane scroll = new ScrollPane(lines);
        scroll.setFitToWidth(true);
        scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scroll.setPrefViewportHeight(Math.min(260, 40 + 32 * lines.getChildren().size()));

        Label total = new Label("TOTAL: " + Format.money(t.getAmount()));
        total.setStyle("-fx-font-weight: bold; -fx-font-size: 15px;");
        Button close = Dialogs.pillButton("Close");
        Region fill = Dialogs.spacer();
        HBox bottom = new HBox(10, total, fill, close);
        bottom.setAlignment(Pos.CENTER_LEFT);

        VBox form = new VBox(10, title, info, scroll, bottom);
        form.setPrefWidth(500);
        Stage stage = Dialogs.popup(table, form);
        close.setOnAction(e -> stage.close());
        stage.showAndWait();
    }

    // Builds one line of the items pop-up (or its header line)
    private HBox itemRow(String name, String qty, String price, String subtotal, boolean header) {
        Label n = new Label(name);
        Label q = new Label(qty);
        Label p = new Label(price);
        Label s = new Label(subtotal);
        n.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(n, Priority.ALWAYS);
        q.setMinWidth(90);
        q.setAlignment(Pos.CENTER_RIGHT);
        p.setMinWidth(90);
        p.setAlignment(Pos.CENTER_RIGHT);
        s.setMinWidth(90);
        s.setAlignment(Pos.CENTER_RIGHT);
        HBox row = new HBox(8, n, q, p, s);
        row.setPadding(new Insets(6, 8, 6, 8));
        String font = header ? "-fx-font-size: 11px; -fx-font-weight: bold;" : "-fx-font-size: 13px;";
        row.setStyle(font + (header ? "-fx-background-color: #F6C3C4;"
                : "-fx-border-color: #DDDDDD; -fx-border-width: 0 0 1 0;"));
        return row;
    }

    // A table cell that shows "3 items" as a link; clicking it opens the items pop-up
    // INHERITANCE: extends TableCell, and @Override below replaces its updateItem method to show a link.
    private class ItemsLinkCell extends TableCell<Transaction, String> {
        private Hyperlink link = new Hyperlink();

        // Sets what to do when the link is clicked
        public ItemsLinkCell() {
            link.setOnAction(e -> {
                Transaction t = (Transaction) getTableRow().getItem();
                if (t != null) {
                    showItems(t);
                }
            });
        }

        // Shows the link in the cell, or nothing for an empty row
        @Override
        protected void updateItem(String text, boolean empty) {
            super.updateItem(text, empty);
            if (empty || text == null) {
                setGraphic(null);
            } else {
                link.setText(text);
                setGraphic(link);
            }
        }
    }

    // A table row that is greyed out when its transaction is voided
    // INHERITANCE: extends TableRow, and @Override below replaces its updateItem method to grey out voided rows.
    private static class TransactionRow extends TableRow<Transaction> {
        // Greys out the row if its transaction is voided
        @Override
        protected void updateItem(Transaction t, boolean empty) {
            super.updateItem(t, empty);
            getStyleClass().remove("voided-row");
            if (!empty && t != null && t.isVoided()) {
                getStyleClass().add("voided-row");
            }
        }
    }
}
