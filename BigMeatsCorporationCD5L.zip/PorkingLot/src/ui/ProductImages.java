package ui;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import javafx.geometry.Rectangle2D;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Rectangle;

// Product pictures: the backend has no picture field, so each one is saved as data/images/<productId>.<extension>
public class ProductImages {
    private static final String FOLDER = "data/images/";
    private static final String[] EXTENSIONS = { "png", "jpg", "jpeg", "gif" };

    // Returns the saved picture of a product (null if it has none)
    public static Image load(String productId) {
        for (String ext : EXTENSIONS) {
            File file = new File(FOLDER + productId + "." + ext);
            if (file.exists()) {
                return new Image(file.toURI().toString());
            }
        }
        return null;
    }

    // Copies the chosen file in as the product's picture, replacing the old one
    public static void save(String productId, File source) throws IOException {
        new File(FOLDER).mkdirs();
        delete(productId);
        String name = source.getName().toLowerCase();
        String ext = name.substring(name.lastIndexOf('.') + 1);
        Files.copy(source.toPath(), new File(FOLDER + productId + "." + ext).toPath(),
                StandardCopyOption.REPLACE_EXISTING);
    }

    // Deletes the saved picture of a product
    public static void delete(String productId) {
        for (String ext : EXTENSIONS) {
            new File(FOLDER + productId + "." + ext).delete();
        }
    }

    // Puts the picture in the box (cropped to fill it), or the image icon if there is none
    public static void fill(StackPane box, Image image, double width, double height) {
        box.getChildren().clear();
        if (image == null) {
            box.getChildren().add(Icons.outline(Icons.IMAGE, 22));
            return;
        }

        double scale = Math.max(width / image.getWidth(), height / image.getHeight());
        double viewWidth = width / scale;
        double viewHeight = height / scale;
        ImageView view = new ImageView(image);
        view.setViewport(new Rectangle2D((image.getWidth() - viewWidth) / 2,
                (image.getHeight() - viewHeight) / 2, viewWidth, viewHeight));
        view.setFitWidth(width);
        view.setFitHeight(height);
        Rectangle clip = new Rectangle(width, height);
        clip.setArcWidth(20);
        clip.setArcHeight(20);
        view.setClip(clip);
        box.getChildren().add(view);
    }

    // Creates a picture box of the given size
    public static StackPane box(Image image, double width, double height) {
        StackPane box = new StackPane();
        box.getStyleClass().add("image-box");
        box.setMinSize(width, height);
        box.setPrefSize(width, height);
        box.setMaxSize(width, height);
        fill(box, image, width, height);
        return box;
    }
}
