package ui;

import app.PorkingLotSystem;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

// Login screen: pink half with the Big Meats logo and tagline, white half with the login form
// INHERITANCE: extends HBox, so the login screen IS a horizontal box with two halves.
public class LoginView extends HBox {
    // Builds both halves and connects the Login button
    public LoginView(PorkingLotSystem system, Runnable onSuccess) {
        StackPane left = new StackPane();
        left.setStyle("-fx-background-color: #F6C3C4;");
        Label tagline = new Label("Big meat, hard to beat");
        tagline.setStyle("-fx-font-family: 'Comic Sans MS'; -fx-font-size: 26px; -fx-font-weight: bold; -fx-text-fill: #C2414E;");
        VBox leftContent = new VBox(18, image("/ui/images/bigmeats.png", 360), tagline);
        leftContent.setAlignment(Pos.CENTER);
        left.getChildren().add(leftContent);

        Label welcome = new Label("Welcome Back!");
        welcome.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");

        TextField username = new TextField();
        PasswordField password = new PasswordField();
        username.getStyleClass().add("login-field");
        password.getStyleClass().add("login-field");

        Label error = new Label();
        error.setStyle("-fx-text-fill: #D32F2F; -fx-font-size: 14px;");

        Button login = new Button("Login");
        login.getStyleClass().add("login-button");
        login.setMaxWidth(Double.MAX_VALUE);
        login.setDefaultButton(true);
        login.setOnAction(e -> {
            if (system.login(username.getText(), password.getText()) == null) {
                error.setText("Invalid username or password.");
                password.clear();
            } else {
                onSuccess.run();
            }
        });

        VBox form = new VBox(8, image("/ui/images/logo_full.png", 490), welcome,
                fieldLabel("Enter your username"), username,
                fieldLabel("Enter your password"), password, login, error);
        form.setMaxWidth(516);
        form.setAlignment(Pos.CENTER_LEFT);
        VBox.setMargin(welcome, new Insets(-2, 0, 4, 0));
        VBox.setMargin(login, new Insets(30, 0, 0, 0));
        welcome.setMaxWidth(Double.MAX_VALUE);
        welcome.setAlignment(Pos.CENTER);

        StackPane right = new StackPane(form);
        right.setStyle("-fx-background-color: white;");

        HBox.setHgrow(left, Priority.ALWAYS);
        HBox.setHgrow(right, Priority.ALWAYS);
        left.setPrefWidth(100);
        right.setPrefWidth(100);
        getChildren().addAll(left, right);
    }

    // Creates the small label above a text field
    private Label fieldLabel(String text) {
        Label l = new Label(text);
        l.setStyle("-fx-font-size: 15px;");
        return l;
    }

    // Loads a picture from the ui/images folder at the given width
    private ImageView image(String path, double width) {
        ImageView view = new ImageView();
        if (LoginView.class.getResource(path) != null) {
            view.setImage(new Image(LoginView.class.getResource(path).toExternalForm()));
        }
        view.setFitWidth(width);
        view.setPreserveRatio(true);
        return view;
    }
}
